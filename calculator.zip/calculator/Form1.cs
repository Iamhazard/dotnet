﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculator
{
    public partial class Form1 : Form
    {
        Double resultValue = 0;
        String operationPerformed = "";
        bool isOperationperformed=false;
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_click(object sender, EventArgs e)
            
        {
            if ((textResult.Text == "0")|| (isOperationperformed))
                textResult.Clear();
            isOperationperformed = false;

            Button button = (Button)sender; 

            if(button.Text ==".")
            {
                if(!textResult.Text.Contains("."))
                    textResult.Text = textResult.Text + button.Text;
            }
            else

         textResult.Text = textResult.Text + button.Text;

        }

        private void operator_click(object sender, EventArgs e)
        {
            Button button = (Button)sender;   //capture all button you click

            if (resultValue != 0)
            {
                button20.PerformClick();
                operationPerformed = button.Text;
                operation_view.Text = resultValue + " " + operationPerformed;
                isOperationperformed = true;
            }else
            {
                operationPerformed = button.Text;
                resultValue = Double.Parse(textResult.Text);
                operation_view.Text = resultValue + " " + operationPerformed;
                isOperationperformed = true;
            }
      

            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textResult.Text = "0";
            resultValue = 0;

        }

        private void button20_Click(object sender, EventArgs e)
        {
            switch(operationPerformed)
            {
                case "+":
                    textResult.Text = (resultValue + Double.Parse(textResult.Text)).ToString();
                    break;
                case "-":
                    textResult.Text = (resultValue  - Double.Parse(textResult.Text)).ToString();
                    break;
                case "*":
                    textResult.Text = (resultValue * Double.Parse(textResult.Text)).ToString();
                    break;
                case "/":
                    textResult.Text = (resultValue / Double.Parse(textResult.Text)).ToString();
                    break;
                    default:
                    break;



           }
            resultValue=Double.Parse(textResult.Text);
            operation_view.Text = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(textResult.Text.Length>0)
            {
                textResult.Text= textResult.Text.Substring(0, textResult.Text.Length-1);

            }
            if (textResult.Text.Length == 0)
            {
                textResult.Text = "0";
            }
        }
    }
}
